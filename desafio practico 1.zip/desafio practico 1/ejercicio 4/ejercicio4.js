const songs = {
    cumbia: {
        songs: ['Cumbia 1', 'Cumbia 2', 'Cumbia 3', 'Cumbia 4', 'Cumbia 5'],
        Image:''